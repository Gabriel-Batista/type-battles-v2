export const FetchConst = {
    API: "https://type-battles-v2-backend.herokuapp.com/",
    API_WS: "wss://type-battles-v2-backend.herokuapp.com/cable",
    HEADERS: { "Content-Type": "application/json", Accept: "application/json" }
};

// export const FetchConst = {
//   API: "http://localhost:3001",
//   API_WS: "ws://localhost:3001/cable",
//   HEADERS: { "Content-Type": "application/json", Accept: "application/json" }
// };