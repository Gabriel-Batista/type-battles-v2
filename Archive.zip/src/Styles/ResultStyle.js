export const H1Style = {
    color: "#FFFFFF",
    fontSize: "4em",
    fontWeight: "normal",
    marginTop: "2em"
};

export const HeaderRowStyle = {
    backgroundColor: "#01111B",
    height: "35em"
};
