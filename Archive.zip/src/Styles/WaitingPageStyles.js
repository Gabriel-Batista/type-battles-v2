export const HeaderRowStyle = {
  backgroundColor: "#01111B",
  height: "35em"
};

export const H1Style = {
    color: "#FFFFFF",
    fontSize: "4em",
    fontWeight: "normal",
    marginBottom: 0,
    marginTop: "1.25em"
};

export const H2Style = {
    fontSize: "1.7em",
    fontWeight: "normal",
    marginTop: "4em"
};