export const ContainingDivStyles = {
}
export const DimmerTextStyle = { fontSize: "6em" }