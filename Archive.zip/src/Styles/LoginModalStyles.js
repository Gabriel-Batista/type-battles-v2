export const LoginButtonStyle = {
  color: "#8EC5FF",
    backgroundColor: "#0D83FF",
    borderRadius: "10px",
    boxShadow: "0px 15px 0px 0px #0A60BA",
    marginTop: "3em"
};

export const SignupButtonStyle = {
    color: "#CCFCCB",
  backgroundColor: "#82D883",
    borderRadius: "10px",
    boxShadow: "0px 15px 0px 0px #32965D",
    marginTop: "3em"
};
